/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.*;
import java.io.IOException;

import controlador.Concurso;
import visual.MainWindows;

/**
 *
 * @author vasha
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                MainWindows gui= null;
                try {
                    gui = new MainWindows();
                    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                    gui.setLocation(dim.width/2-gui.getSize().width/2, dim.height/2-gui.getSize().height/2);
                    gui.setVisible(true);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
}
