package excepciones;

/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public class ExceptionEquipoVacio extends Exception {
    public ExceptionEquipoVacio() {
        //TODO Falta definir mensaje
        super();
    }
}
