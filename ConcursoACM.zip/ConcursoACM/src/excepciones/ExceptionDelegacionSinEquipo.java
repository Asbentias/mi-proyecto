package excepciones;

/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public class ExceptionDelegacionSinEquipo extends Exception {
    public ExceptionDelegacionSinEquipo() {
        //TODO Falta generar el mensaje
        super("");
    }
}
