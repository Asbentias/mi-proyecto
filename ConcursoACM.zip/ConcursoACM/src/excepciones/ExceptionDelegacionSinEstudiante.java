package excepciones;

/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public class ExceptionDelegacionSinEstudiante extends Exception {
    public ExceptionDelegacionSinEstudiante() {
        //Falta definir mensaje de exception
        super("");
    }

    /**
     * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
     * @date 22/1/23
     */
    public static class ExceptionEquipoNoEncontrado extends Exception {
        public ExceptionEquipoNoEncontrado() {
            //Falta Generar mensaje
            super("");
        }
    }
}
