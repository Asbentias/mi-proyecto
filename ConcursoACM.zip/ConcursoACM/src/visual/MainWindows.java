/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controlador.Concurso;
import excepciones.ExcepcionContrsennaJefeDelegacionSimilar;
import excepciones.ExcepcionExisteRegionRegistrada;
import excepciones.ExcepcionPosFueraDeRango;
import modelo.Delegacion;

import javax.sound.midi.ShortMessage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

/**
 *
 * @author vasha
 */
public class MainWindows extends javax.swing.JFrame implements ActionListener {

    private Concurso concurso;
    private JPanel jPanelHeader;
    private Box.Filler fillerHeader;
    private JPanel jPanelContent;
    private JButton jButtonCloseSession;
    private JButton jButtonAddDelegacion;
    private JButton jButtonSimularConcurso;
    private JButton jButtonConformarEquipo;

    /**
     * Creates new form MainWindows
     */
    public MainWindows() throws IOException {
        //initComponents();
        concurso = new Concurso();
        createUIComponents();
        createConnects();
        this.setExtendedState(MAXIMIZED_BOTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/resource/iconos/cartman.png"));
        setIconImage(icon);
        showDialogModalContrasenna();
    }

    private void createConnects() {
        this.jButtonCloseSession.addActionListener(this);
        this.jButtonAddDelegacion.addActionListener(this);
        this.jButtonConformarEquipo.addActionListener(this);
        this.jButtonSimularConcurso.addActionListener(this);
    }

    private void createUIComponents(){
        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        jPanelHeader = new JPanel();
        jPanelHeader.setMaximumSize(new Dimension(32767, 75));
        jPanelHeader.setMinimumSize(new Dimension(0, 75));
        jPanelHeader.setPreferredSize(new Dimension(644, 75));
        jPanelHeader.setPreferredSize(new Dimension(644, 75));
        jPanelHeader.setLayout(new BoxLayout(jPanelHeader, BoxLayout.X_AXIS));


        fillerHeader = new Box.Filler(new Dimension(32767, 100),
                new Dimension(45, 100),
                new Dimension(32767, 32767));
        jButtonCloseSession = new JButton();
        jButtonCloseSession.setIcon(new ImageIcon(getClass().getResource("/resource/iconos/cartman.png")));
        jButtonCloseSession.setToolTipText("Cerrar session");
        jButtonCloseSession.setBorderPainted(false);
        jButtonCloseSession.setContentAreaFilled(false);
        jButtonCloseSession.setMargin(new Insets(2, 2, 2, 2));
        jButtonCloseSession.setMaximumSize(new Dimension(50, 50));
        jButtonCloseSession.setPreferredSize(new Dimension(50, 50));

        jButtonAddDelegacion = new JButton();
        jButtonAddDelegacion.setIcon(new ImageIcon(getClass().getResource("/resource/iconos/cartman.png")));
        jButtonAddDelegacion.setToolTipText("Adicionar delegación");
        jButtonAddDelegacion.setBorderPainted(false);
        jButtonAddDelegacion.setContentAreaFilled(false);
        jButtonAddDelegacion.setMargin(new Insets(2, 2, 2, 2));
        jButtonAddDelegacion.setMaximumSize(new Dimension(50, 50));
        jButtonAddDelegacion.setPreferredSize(new Dimension(50, 50));

        jButtonConformarEquipo = new JButton();
        jButtonConformarEquipo.setIcon(new ImageIcon(getClass().getResource("/resource/iconos/cartman.png")));
        jButtonConformarEquipo.setToolTipText("Conformar equipo");
        jButtonConformarEquipo.setBorderPainted(false);
        jButtonConformarEquipo.setContentAreaFilled(false);
        jButtonConformarEquipo.setMargin(new Insets(2, 2, 2, 2));
        jButtonConformarEquipo.setMaximumSize(new Dimension(50, 50));
        jButtonConformarEquipo.setPreferredSize(new Dimension(50, 50));

        jButtonSimularConcurso = new JButton();
        jButtonSimularConcurso.setIcon(new ImageIcon(getClass().getResource("/resource/iconos/cartman.png")));
        jButtonSimularConcurso.setToolTipText("Simular concurso");
        jButtonSimularConcurso.setBorderPainted(false);
        jButtonSimularConcurso.setContentAreaFilled(false);
        jButtonSimularConcurso.setMargin(new Insets(2, 2, 2, 2));
        jButtonSimularConcurso.setMaximumSize(new Dimension(50, 50));
        jButtonSimularConcurso.setPreferredSize(new Dimension(50, 50));

        jPanelHeader.add(jButtonAddDelegacion);
        jPanelHeader.add(jButtonSimularConcurso);
        jPanelHeader.add(jButtonConformarEquipo);
        jPanelHeader.add(fillerHeader);
        jPanelHeader.add(jButtonCloseSession);

        jPanelContent = new JPanel();
        jPanelContent.setLayout(new BoxLayout(jPanelContent, BoxLayout.X_AXIS));

//        jPanelUpdateAccounts = new JPanel();
//        jPanelUpdateAccounts.setBorder(BorderFactory.createTitledBorder(null, "Actualización de estados de cuentas",
//                TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION,
//                new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
//        jPanelUpdateAccounts.setLayout(new BoxLayout(jPanelUpdateAccounts, BoxLayout.X_AXIS));
//
//        jScrollPanelUpdateAccounts = new JScrollPane();
//
//        modelUpdateAccounts = new UpdateAccountsModel();
//        renderTableUpdateAccounts = new UpdateAccountsTableCellRenderer();
//
//        jTableUpdateAccounts = new UpdateAccountsTable();
//        jTableUpdateAccounts.setModel(modelUpdateAccounts);
//        jTableUpdateAccounts.setDefaultRenderer(Object.class,renderTableUpdateAccounts);
//
//        TableColumn column = jTableUpdateAccounts.getColumnModel().getColumn(0);
//        column.setPreferredWidth(100);
//        column.setMaxWidth(100);
//        column.setMinWidth(100);
//
//        column = jTableUpdateAccounts.getColumnModel().getColumn(2);
//        column.setPreferredWidth(130);
//        column.setMaxWidth(130);
//        column.setMinWidth(130);
//
//        column = jTableUpdateAccounts.getColumnModel().getColumn(3);
//        column.setPreferredWidth(140);
//        column.setMaxWidth(140);
//        column.setMinWidth(140);
//
//        jTableUpdateAccounts.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
//
//        jScrollPanelUpdateAccounts.setViewportView(jTableUpdateAccounts);
//        jPanelUpdateAccounts.add(jScrollPanelUpdateAccounts);
//
//        jPanelOperationsAccounts = new JPanel();
//        jPanelOperationsAccounts.setBorder(BorderFactory.createTitledBorder(null, "Operaciones de cuentas",
//                TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION,
//                new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
//        jPanelOperationsAccounts.setLayout(new BoxLayout(jPanelOperationsAccounts, BoxLayout.X_AXIS));
//
//        jScrollPanelOperationsAccounts = new JScrollPane();
//
//        modelOperationsAccounts = new OperationsAccountsModel();
//        renderTableOperationAccount = new OperationAccountsTableCellRenderer();
//
//        jTableOperationsAccounts = new OperationAccountsTable();
//        jTableOperationsAccounts.setModel(modelOperationsAccounts);
//        jTableOperationsAccounts.setDefaultRenderer(Object.class,renderTableOperationAccount);
//
//        column = jTableOperationsAccounts.getColumnModel().getColumn(0);
//        column.setPreferredWidth(70);
//        column.setMaxWidth(70);
//        column.setMinWidth(70);
//
//        column = jTableOperationsAccounts.getColumnModel().getColumn(1);
//        column.setPreferredWidth(100);
//        column.setMaxWidth(100);
//        column.setMinWidth(100);
//
//        column = jTableOperationsAccounts.getColumnModel().getColumn(3);
//        column.setPreferredWidth(130);
//        column.setMaxWidth(130);
//        column.setMinWidth(130);
//
//        column = jTableOperationsAccounts.getColumnModel().getColumn(4);
//        column.setPreferredWidth(130);
//        column.setMaxWidth(130);
//        column.setMinWidth(130);
//
//        jTableOperationsAccounts.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
//        jScrollPanelOperationsAccounts.setViewportView(jTableOperationsAccounts);
//        jPanelOperationsAccounts.add(jScrollPanelOperationsAccounts);
//
//        jPanelContent.add(jPanelUpdateAccounts);
//        jPanelContent.add(jPanelOperationsAccounts);

        getContentPane().add(jPanelHeader);
        getContentPane().add(jPanelContent);

        setTitle("Concurso ACM ");

        pack();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

//        jPanel1 = new javax.swing.JPanel();
//        jButton6 = new javax.swing.JButton();
//        jButton7 = new javax.swing.JButton();
//        jButton8 = new javax.swing.JButton();
//        jButton9 = new javax.swing.JButton();
//        jButton10 = new javax.swing.JButton();
//        jButton11 = new javax.swing.JButton();
//        jPanel2 = new javax.swing.JPanel();
//
//        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
//
//        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resource/iconos/cartman.png"))); // NOI18N
//        jButton6.setText("jButton6");
//
//        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resource/iconos/cartman.png"))); // NOI18N
//        jButton7.setText("jButton7");
//
//        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resource/iconos/cartman.png"))); // NOI18N
//        jButton8.setText("jButton8");
//
//        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resource/iconos/cartman.png"))); // NOI18N
//        jButton9.setText("jButton9");
//
//        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resource/iconos/cartman.png"))); // NOI18N
//        jButton10.setText("jButton10");
//
//        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resource/iconos/cartman.png"))); // NOI18N
//        jButton11.setText("jButton11");
//
//        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
//        jPanel1.setLayout(jPanel1Layout);
//        jPanel1Layout.setHorizontalGroup(
//            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
//            .add(jPanel1Layout.createSequentialGroup()
//                .addContainerGap()
//                .add(jButton6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 61, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
//                .add(18, 18, 18)
//                .add(jButton7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 63, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
//                .add(18, 18, 18)
//                .add(jButton8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 61, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
//                .add(18, 18, 18)
//                .add(jButton9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 61, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
//                .add(18, 18, 18)
//                .add(jButton10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 61, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
//                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 160, Short.MAX_VALUE)
//                .add(jButton11, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 62, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
//                .addContainerGap())
//        );
//        jPanel1Layout.setVerticalGroup(
//            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
//            .add(jPanel1Layout.createSequentialGroup()
//                .addContainerGap()
//                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
//                    .add(jButton11, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
//                    .add(jButton10, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
//                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jButton9, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
//                    .add(jButton8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
//                    .add(jButton7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
//                    .add(jButton6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE))
//                .addContainerGap())
//        );
//
//        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
//        jPanel2.setLayout(jPanel2Layout);
//        jPanel2Layout.setHorizontalGroup(
//            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
//            .add(0, 0, Short.MAX_VALUE)
//        );
//        jPanel2Layout.setVerticalGroup(
//            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
//            .add(0, 308, Short.MAX_VALUE)
//        );
//
//        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
//        getContentPane().setLayout(layout);
//        layout.setHorizontalGroup(
//            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
//            .add(jPanel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
//            .add(jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
//        );
//        layout.setVerticalGroup(
//            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
//            .add(layout.createSequentialGroup()
//                .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
//                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 58, Short.MAX_VALUE)
//                .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
//        );
//
//        pack();
    }// </editor-fold>//GEN-END:initComponents



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        Object obj = actionEvent.getSource();
        if (this.jButtonCloseSession == obj){
            showDialogModalContrasenna();
        }else if(this.jButtonConformarEquipo == obj){
            showDialogModalConformarEquipos();
        }else if(this.jButtonAddDelegacion == obj){
            showDialogModalAddDelegacion();
        }else if(this.jButtonSimularConcurso == obj){
            simularConcurso();
        }
    }

    private void simularConcurso(){
        showDialogMessage("Upss !!. Lo sentimos solo en la version de pago");
    }

    private void showDialogModalAddDelegacion(){
        AdicionarDelegacion dialog =new AdicionarDelegacion(this, true);

        boolean accepted = dialog.exec();
        if(accepted==true){
            Delegacion del = dialog.getDelegacion();
            try {
                concurso.addDelegacion(del);
            } catch (ExcepcionPosFueraDeRango e) {
                showDialogMessage(e.getMessage());
            } catch (ExcepcionExisteRegionRegistrada e) {
                showDialogMessage(e.getMessage());
            } catch (ExcepcionContrsennaJefeDelegacionSimilar e) {
                showDialogMessage(e.getMessage());
            }

        }
    }

    private void showDialogModalConformarEquipos() {
        showDialogMessage("Upss !!. Lo sentimos solo en la version de pago");
    }

    private void showDialogModalContrasenna() {
        PantallaAcreditacion dialog =new PantallaAcreditacion(this, true);

        boolean accepted = dialog.exec();
        if(accepted==true){
            String contrsena = dialog.getContrsenna();
        }
    }

    public boolean checkPassword(String contrsenna) {
        boolean check = false;
        try {
            check=(concurso.esAdmin(contrsenna) || concurso.esJefeDelegacion(contrsenna));
        } catch (ExcepcionPosFueraDeRango e) {
            e.printStackTrace();
        }
        return check;
    }

    public void showDialogMessage(String _messge){
        JOptionPane.showMessageDialog(this,_messge);
    }
    // End of variables declaration//GEN-END:variables
}
