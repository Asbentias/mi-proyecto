package modelo;

import java.io.Serializable;

/**
 *
 * @author Sebastián Hernández
 */
public class PreguntaB extends Pregunta implements Serializable{

    public PreguntaB(int numero, String texto, int puntuacion_max) {
        super(numero, texto, puntuacion_max);
    }

    @Override
    public int calificacion (double porciento){
        int puntuacion = 0;
        if(porciento<=100&&porciento>=95){
            puntuacion=this.puntuacion_max;
        }
        else if(porciento<=94&&porciento>=80){
            puntuacion=this.puntuacion_max-2;
        }
        else if(porciento<=79&&porciento>=65){
            puntuacion=this.puntuacion_max-4;
        }

        return puntuacion;
    }

}
