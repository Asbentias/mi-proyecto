package modelo;

import excepciones.ExcepcionPosFueraDeRango;
import excepciones.ExceptionEquipoLleno;
import excepciones.ExceptionEquipoVacio;
import excepciones.ExceptionEstudianteNoEncontrado;
import util.ListaGenerica;

import java.io.Serializable;

/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public class Equipo implements Serializable {

    private ListaGenerica<Persona> estudiantes;
    private String identificador;
    private int cantidadPuntos;

    public Equipo(ListaGenerica<Persona> estudiantes, String identificador) {
        this.estudiantes = estudiantes;
        this.identificador = identificador;
        this.cantidadPuntos = 0;
    }

    public ListaGenerica<Persona> getEstudiantes() {
        return estudiantes;
    }

    public void setEstudiantes(ListaGenerica<Persona> estudiantes) {
        this.estudiantes = estudiantes;
    }


    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public int getCantidadPuntos() {
        return cantidadPuntos;
    }

    public void setCantidadPuntos(int cantidadPuntos) {
        this.cantidadPuntos = cantidadPuntos;
    }

    public void addIntegrante(Persona estudiante) throws ExceptionEquipoLleno{
        if( estudiantes.cantidadElementos() <3){
            estudiantes.adicionar(estudiante);
        }else{
            throw new ExceptionEquipoLleno();
        }
    }

    public void eliminarEstudiante(String _identificador) throws ExceptionEquipoVacio, ExceptionEstudianteNoEncontrado, ExcepcionPosFueraDeRango {
        if (estudiantes.cantidadElementos() > 0){
            int pos =-1;

            for(int i=0;i<estudiantes.cantidadElementos() && pos!=-1 ;i++){
                if (estudiantes.obtener(i).getId().compareTo(_identificador)==0)
                    pos =i;
            }
            if (pos != -1 )
                estudiantes.eliminar(pos);
            else
                throw new ExceptionEstudianteNoEncontrado();
        }else{
            throw new ExceptionEquipoVacio();
        }
    }
}
