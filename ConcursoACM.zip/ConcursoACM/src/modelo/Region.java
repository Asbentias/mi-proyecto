package modelo;

/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public enum Region {
    ASIA,
    AMERICA,
    AFRICA,
    EUROPA,
    AUSTRALIA,
    AMERICA_LATINA,
    AMERICA_NORTE,
    AMERICA_SUR
}
