package modelo;

import java.io.Serializable;

/**
 *
 * @author Sebastián Hernández
 */
public class PreguntaA extends Pregunta implements Serializable{

    public PreguntaA(int numero, String texto, int puntuacion_max) {
        super(numero, texto, puntuacion_max);
    }

    @Override
    public int calificacion (double porciento){
        int puntuacion = 0;
        if(porciento<=100&&porciento>=90){
            puntuacion=this.puntuacion_max;
        }
        else if(porciento<=89&&porciento>=70){
            puntuacion=this.puntuacion_max/2;
        }
        else if(porciento<=69&&porciento>=50){
            puntuacion=this.puntuacion_max/3;
        }

        return puntuacion;
    }



}
