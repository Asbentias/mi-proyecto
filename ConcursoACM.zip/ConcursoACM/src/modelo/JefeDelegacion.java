package modelo;

import java.io.Serializable;

/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public class JefeDelegacion extends Persona implements Serializable {

    private String contrasenia;

    public JefeDelegacion(String id, int edad, String sexo, String pais, String codigo_telefonico, String contrasenia) {
        super(id, edad, sexo, pais,  codigo_telefonico);
        this.contrasenia = contrasenia;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }
}
