package modelo;

/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public class Estudiante extends  Persona{

    public Estudiante(String id, int edad, String sexo, String pais,String codigo_telefonico) {
        super(id, edad, sexo, pais,  codigo_telefonico);
    }
}
