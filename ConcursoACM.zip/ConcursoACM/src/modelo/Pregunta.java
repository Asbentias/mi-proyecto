package modelo;

import java.io.Serializable;

/**
 *
 * @author Sebastián Hernández
 */
public abstract class Pregunta implements Serializable{

    protected int numero;
    protected String texto;
    protected int puntuacion_max;

    public Pregunta(int numero, String texto, int puntuacion_max) {
        this.numero = numero;
        this.texto = texto;
        this.puntuacion_max=puntuacion_max;
    }

    public abstract int calificacion(double porciento);

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public int getPuntuacion_max() {
        return puntuacion_max;
    }

    public void setPuntuacion_max(int puntuacion_max) {
        this.puntuacion_max = puntuacion_max;
    }
}
