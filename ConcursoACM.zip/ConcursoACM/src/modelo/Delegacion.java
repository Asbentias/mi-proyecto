package modelo;

import excepciones.*;
import util.ListaGenerica;

/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public class Delegacion {
    private Persona jefeDelegacion;
    private ListaGenerica<Persona> estudiantes;
    private ListaGenerica<Equipo> equipos;
    private Region region;



    private final int MAX_CONCURSANTES=15;

    public Delegacion(Persona jefeDelegacion, ListaGenerica<Persona> estudiantes, Region region) {
        this.jefeDelegacion = jefeDelegacion;
        this.estudiantes = estudiantes;
        this.region = region;
        this.equipos = new ListaGenerica<Equipo>();
    }

    public Region getRegion() {
        return region;
    }

    public void setRegion(Region region) {
        this.region = region;
    }

    public Persona getJefeDelegacion() {
        return jefeDelegacion;
    }

    public void setJefeDelegacion(Persona jefeDelegacion) {
        this.jefeDelegacion = jefeDelegacion;
    }

    public ListaGenerica<Persona> getEstudiantes() {
        return estudiantes;
    }

    public void setEstudiantes(ListaGenerica<Persona> estudiantes) {
        this.estudiantes = estudiantes;
    }

    public ListaGenerica<Equipo> getEquipos() {
        return equipos;
    }

    public void setEquipos(ListaGenerica<Equipo> equipos) {
        this.equipos = equipos;
    }

    public void addEquipo(Equipo _equipo) throws ExceptionDelegacionEquiposCompletos{
        if( equipos.cantidadElementos() <3)
            equipos.adicionar(_equipo);
        else
            throw new ExceptionDelegacionEquiposCompletos();
    }

    public void eliminarEquipo(String identificadorEquipo) throws ExceptionDelegacionSinEstudiante.ExceptionEquipoNoEncontrado, ExceptionDelegacionSinEquipo, ExcepcionPosFueraDeRango {
        int pos =-1;

        if(equipos.cantidadElementos()>0){
            for(int i=0;i<equipos.cantidadElementos() && pos !=-1 ;i++){
                if( equipos.obtener(i).getIdentificador().compareTo(identificadorEquipo)==0 )
                    pos = i;
            }
            if (pos != -1 )
                equipos.eliminar(pos);
            else
                throw new ExceptionDelegacionSinEstudiante.ExceptionEquipoNoEncontrado();
        }else{
            throw new ExceptionDelegacionSinEquipo();
        }
    }

    public void cambiarContrasena(String nuevaContrasena){
        if(jefeDelegacion!=null && jefeDelegacion instanceof JefeDelegacion){
            JefeDelegacion j = (JefeDelegacion) jefeDelegacion;
            if(j!=null)
                j.setContrasenia(nuevaContrasena);
        }
    }

    public void eliminarEstudiante(String _identificador) throws ExceptionEstudianteNoEncontrado, ExceptionEquipoVacio, ExceptionDelegacionSinEstudiante, ExcepcionPosFueraDeRango {

        for(int i=0;i<equipos.cantidadElementos();i++)
            equipos.obtener(i).eliminarEstudiante(_identificador);

        if(estudiantes.cantidadElementos()>0){
            int pos =-1;
            for(int i=0;i<estudiantes.cantidadElementos() && pos!=-1;i++) {
                if( estudiantes.obtener(i).getId().compareTo(_identificador)==0)
                    pos =i;
            }
            if (pos != -1)
                estudiantes.eliminar(pos);
            else
                throw new ExceptionEstudianteNoEncontrado();
        }else
            throw new ExceptionDelegacionSinEstudiante();


    }

    public void addEstudiante(Persona _estudiante) throws ExcepcionDelegacionEstudianteCompleto {
        if( estudiantes.cantidadElementos() <MAX_CONCURSANTES  ){
            estudiantes.adicionar(_estudiante);
        }else{
            throw new ExcepcionDelegacionEstudianteCompleto();
        }
    }

    public ListaGenerica<Persona> getDelegacion() throws ExcepcionPosFueraDeRango {
        ListaGenerica<Persona> delegacion = new ListaGenerica<Persona>();
        delegacion.adicionar(jefeDelegacion);
        for(int i=0;i<estudiantes.cantidadElementos();i++)
            delegacion.adicionar(estudiantes.obtener(i));
        return delegacion;
    }

    public boolean chequearContrasennaJefeDelegacion(String _contrasena){
        if(jefeDelegacion!=null && jefeDelegacion instanceof JefeDelegacion){
            JefeDelegacion f = (JefeDelegacion) jefeDelegacion;
            if (f.getContrasenia().compareTo(_contrasena)==0)
                return true;
        }
        return false;
    }

    public String getContrsennaJefe(){
        String contrsenna ="";
        if(jefeDelegacion!=null && jefeDelegacion instanceof JefeDelegacion){
            JefeDelegacion f = (JefeDelegacion) jefeDelegacion;
            contrsenna = f.getContrasenia();
        }
        return contrsenna;
    }


}
