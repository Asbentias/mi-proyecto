package modelo;

import util.ListaGenerica;

import java.io.Serializable;

/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public class EquipoJunior extends Equipo implements Serializable {
    public EquipoJunior(ListaGenerica<Persona> estudiantes, String identificador) {
        super(estudiantes, identificador);
    }
}
