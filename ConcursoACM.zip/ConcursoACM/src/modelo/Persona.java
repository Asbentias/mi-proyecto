package modelo;

import java.io.Serializable;

/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public abstract  class Persona implements Serializable {

    protected String id;
    protected int edad;
    protected String sexo;
    protected String pais;

    protected String codigo_telefonico;

    public Persona(String id, int edad, String sexo, String pais, String codigo_telefonico) {
        this.id = id;
        this.edad = edad;
        this.sexo = sexo;
        this.pais = pais;
        this.codigo_telefonico = codigo_telefonico;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }


    public String getCodigo_telefonico() {
        return codigo_telefonico;
    }

    public void setCodigo_telefonico(String codigo_telefonico) {
        this.codigo_telefonico = codigo_telefonico;
    }
}
