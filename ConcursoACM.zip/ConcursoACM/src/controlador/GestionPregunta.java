package controlador;

import modelo.Pregunta;
import modelo.PreguntaA;
import modelo.PreguntaB;
import util.ListaGenerica;
import util.ReadFileFromResources;

import java.io.*;
import java.io.BufferedReader;
import util.ReadFileFromResources;


/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public class GestionPregunta {

    private final String FILE_NAME= "resource/data/preguntas.txt" ;
    private final String SEPARATOR = "@#@";

    public GestionPregunta() {
    }

    public ListaGenerica<Pregunta> cargarPreguntas() throws IOException {
        return cargarPreguntasTxt();
    }

    private ListaGenerica<Pregunta> cargarPreguntasTxt() throws IOException {
        ListaGenerica<Pregunta> preguntas = new ListaGenerica<Pregunta>();

        ReadFileFromResources reader =new ReadFileFromResources();
        InputStream inputStream= reader.getFileAsIOStream(this.FILE_NAME);

        try (InputStreamReader isr = new InputStreamReader(inputStream);
             BufferedReader br = new BufferedReader(isr);)
        {
            String line;
            while ((line = br.readLine()) != null) {
                String [] partes = line.split(SEPARATOR);
                Pregunta p = validarPregunta(partes);
                if (p!=null)
                    preguntas.adicionar(p);
            }
            inputStream.close();
        }

        return preguntas;
    }

    private boolean tipoPregunta(String tipo){
        return ((tipo.compareTo("A")==0 || tipo.compareTo("B")==0) ? true: false);
    }

    private boolean longitudPregunta(String _pregunta){
        _pregunta=_pregunta.trim();
        return ((_pregunta.length()<250)? true:false);
    }

    private boolean esNumero(String _dato){
        boolean es = true;
        try {
            Integer.parseInt(_dato);
        }catch (Exception e){
            es = false;
        }
        return es;
    }

    private Pregunta validarPregunta(String [] datos){
        Pregunta p = null;
        if( datos.length ==4 && tipoPregunta(datos[0]) == true &&
                longitudPregunta(datos[3]) && esNumero(datos[1]) &&
        esNumero(datos[2])){
            if(datos[0].compareTo("A")==0)
                p =new PreguntaA(Integer.valueOf(datos[1]),datos[3].trim(),Integer.valueOf(datos[2]));
            else
                p =new PreguntaB(Integer.valueOf(datos[1]),datos[3].trim(),Integer.valueOf(datos[2]));
        }
        return p;
    }
}
