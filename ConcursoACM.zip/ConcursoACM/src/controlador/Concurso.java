package controlador;

import excepciones.ExcepcionContrsennaJefeDelegacionSimilar;
import excepciones.ExcepcionExisteRegionRegistrada;
import excepciones.ExcepcionPosFueraDeRango;
import modelo.*;
import util.GeneradorAleatorio;
import util.ListaGenerica;

import java.io.IOException;


/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public class Concurso {
    private final String ADMIN_CONTRASENNA = "admin*";


    private ListaGenerica<Delegacion> delegaciones;
    private ListaGenerica<Pregunta> preguntas;
    private GestionPregunta bancoPreguntas;
    private GeneradorAleatorio generadorIDEquipo;

    public Concurso() throws IOException {
        this.delegaciones = new ListaGenerica<Delegacion>();
        this.preguntas = new ListaGenerica<Pregunta>();
        this.bancoPreguntas = new GestionPregunta();
        this.generadorIDEquipo = new GeneradorAleatorio();
        cargarPreguntasDelBanco();
    }

    private void cargarPreguntasDelBanco() throws IOException {
        preguntas = bancoPreguntas.cargarPreguntas();
    }

    public String getADMIN_CONTRASENNA() {
        return ADMIN_CONTRASENNA;
    }

    public ListaGenerica<Delegacion> getDelegaciones() {
        return delegaciones;
    }

    public void setDelegaciones(ListaGenerica<Delegacion> delegaciones) {
        this.delegaciones = delegaciones;
    }

    public ListaGenerica<Pregunta> getPreguntas() {
        return preguntas;
    }

    public void setPreguntas(ListaGenerica<Pregunta> preguntas) {
        this.preguntas = preguntas;
    }

    public boolean esAdmin(String _contrasenna){
        return ( ADMIN_CONTRASENNA.compareTo(_contrasenna)==0 ? true: false);
    }
    
    public boolean esJefeDelegacion(String _contrasenna) throws ExcepcionPosFueraDeRango {
        boolean esJefe = false;
        for(int i=0;i<delegaciones.cantidadElementos() && esJefe == false;i++){
            if(delegaciones.obtener(i).getJefeDelegacion()!=null){
                Persona a = delegaciones.obtener(i).getJefeDelegacion();
                if(a instanceof JefeDelegacion){
                    JefeDelegacion b = (JefeDelegacion) a;
                    if( b.getContrasenia().compareTo(_contrasenna)==0)
                        esJefe = true;
                }
            }
        }
        return esJefe;
    }

    public boolean existeRegion(Region _region) throws ExcepcionPosFueraDeRango {
        for(int i=0;i< delegaciones.cantidadElementos();i++){
            if(delegaciones.obtener(i).getRegion()==_region)
                return true;
        }
        return false;
    }

    private boolean contrasenaJefeDelegacionSimilar(String _contrasenna){

        return false;
    }

    public void addDelegacion(Delegacion delegacion) throws ExcepcionPosFueraDeRango, ExcepcionExisteRegionRegistrada, ExcepcionContrsennaJefeDelegacionSimilar {
        Region r = delegacion.getRegion();
        if(existeRegion(r)==false){
            for(int i=0;i<delegaciones.cantidadElementos();i++){
                if(delegaciones.obtener(i).chequearContrasennaJefeDelegacion(delegacion.getContrsennaJefe())==true)
                    throw new ExcepcionContrsennaJefeDelegacionSimilar();
            }
        }else
            throw new ExcepcionExisteRegionRegistrada();
    }

    public void eliminarDelegacion(Region _region){

    }

    public void addJefeDelegacion(Persona jefe, Region _region){

    }

    public void eliminarJefeDelegacion(Region _region){

    }

    public void addEstudiante(Persona estudiante, Region _region){

    }

    public void eliminarEstudiante(String identificador){

    }

    public void addEquipo(Equipo _equipo, Region _region){

    }

    public void eliminarEquipo(int _identificador){

    }

    public ListaGenerica<Persona> filtrarRegion(Region _region){
        ListaGenerica<Persona> listado = new ListaGenerica<>();
        return listado;
    }

    public ListaGenerica<Persona> filtrarPais(String Pais){
        ListaGenerica<Persona> listado = new ListaGenerica<>();
        return listado;
    }
    
    public void simulacion(){

    }
}
