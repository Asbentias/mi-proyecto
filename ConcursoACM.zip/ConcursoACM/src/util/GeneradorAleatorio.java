package util;

import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author Luis Andrés Valido Fajardo +53 53694742  luis.valido1989@gmail.com
 * @date 22/1/23
 */
public class GeneradorAleatorio {
    private static Set<String> idsGenerateString = new TreeSet<String>();

    private static Random random = new Random();

    private int getRandomInt(int min, int max) {
        return random.nextInt(max - min) + min;
    }

    public String generateIdentity() {
        String ci=null;
        do {
            int year = getRandomInt(0, 99);
            int month = getRandomInt(1, 12);
            int day = getRandomInt(1, 28);
            int invoice= getRandomInt(0, 99999);
            ci= String.format("%02d",year)+String.format("%02d",month)+String.format("%02d",day)+String.format("%05d",invoice);
        }while(idsGenerateString.contains(ci)==true);
        idsGenerateString.add(ci);
        return ci;
    }
}
