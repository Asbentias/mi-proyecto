package util;


import excepciones.*;

/**
 *
 * @author Sebastián Hernández
 * @param <T>
 */
public class ListaGenerica<T> {

    public int cantMax;
    public int cantReal;
    public T[] elementos;

    public ListaGenerica (){
        this.cantMax = 10;
        this.cantReal =0;
        this.elementos=(T[]) new Object[this.cantMax];
    }
    public void adicionar (T valor){
        if(cantMax==cantReal){
            redimensionarArreglo();}
        elementos[cantReal]=valor;
        cantReal++;
    }
    public void insertar(int pos ,T valor) throws ExcepcionPosFueraDeRango {
        if(0<=pos&&pos<cantReal){
            if(cantReal==cantMax){
                redimensionarArreglo();
            }
            for(int i=cantReal;i<=pos;i--){
                elementos[i]=elementos[i-1];
            }
            elementos[pos]=valor;
            cantReal++;
        }
        else{
            throw new ExcepcionPosFueraDeRango();
        }
    }
    public void eliminar(int pos) throws ExcepcionPosFueraDeRango {
        if(0<=pos&&pos<cantReal){
            for(int i=0;i<cantReal;i++){
                elementos[i]=elementos[i+1];
            }
            cantReal--;
        }
        else{
            throw new ExcepcionPosFueraDeRango();
        }

    }
    public T obtener (int pos) throws ExcepcionPosFueraDeRango {
        if(0<=pos&&pos<cantReal){
            return elementos[pos];
        }
        else{
            throw new ExcepcionPosFueraDeRango();
        }
    }

    public int cantidadElementos(){

        return cantReal;
    }
    private void redimensionarArreglo(){
        T[] copia =(T[]) new Object[cantMax];
        for(int i=0;i<cantReal;i++){
            copia[i]=elementos[i];
        }
        cantMax+=10;
        elementos= (T[]) new Object [cantReal];

        for(int i=0;i<cantReal;i++){
            elementos[i]=copia[i];
        }
    }
}

